<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NilaiKeterampilanByKd extends Model
{
    protected $table = 'get_nilai_keterampilan_siswa_by_kd';
}
