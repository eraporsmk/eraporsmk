<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NilaiAkhirPengetahuan extends Model
{
    protected $table = 'view_nilai_akhir_pengetahuan';
}
