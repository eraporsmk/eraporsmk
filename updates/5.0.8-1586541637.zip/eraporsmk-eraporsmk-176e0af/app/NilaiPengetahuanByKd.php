<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NilaiPengetahuanByKd extends Model
{
    protected $table = 'get_nilai_pengetahuan_siswa_by_kd';
}
