<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NilaiAkhirKeterampilan extends Model
{
    protected $table = 'view_nilai_akhir_keterampilan';
}
