<?php

return [

    // Tracking
    'google' => [
        'analytics-key' => env('TREATS_GA_ID'),
    ],

];
