<?php
phpinfo();