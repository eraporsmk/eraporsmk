INSERT INTO ref.level_wilayah VALUES (0, 'Indonesia', '2013-05-13 00:00:00', '2016-07-22 06:00:00', NULL, '1901-01-01 00:00:00');
INSERT INTO ref.level_wilayah VALUES (1, 'Propinsi', '2013-05-13 00:00:00', '2016-07-22 06:00:00', NULL, '1901-01-01 00:00:00');
INSERT INTO ref.level_wilayah VALUES (2, 'Kab / Kota', '2013-05-13 00:00:00', '2016-07-22 06:00:00', NULL, '1901-01-01 00:00:00');
INSERT INTO ref.level_wilayah VALUES (3, 'Kecamatan', '2013-05-13 00:00:00', '2016-07-22 06:00:00', NULL, '1901-01-01 00:00:00');
INSERT INTO ref.level_wilayah VALUES (4, 'Desa', '2015-07-31 00:00:00', '2016-07-22 06:00:00', NULL, '1901-01-01 00:00:00');