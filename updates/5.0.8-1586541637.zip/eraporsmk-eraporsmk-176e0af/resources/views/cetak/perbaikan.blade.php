@extends('layouts.cetak')
@section('content')
perbaikan
@endsection